package com.basicsstrong.functional.section2;

public interface MathOperation {
	
	public void operation(int a, int b);

}
