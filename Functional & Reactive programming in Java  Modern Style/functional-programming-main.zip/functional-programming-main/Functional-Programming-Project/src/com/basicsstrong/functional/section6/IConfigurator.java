package com.basicsstrong.functional.section6;

public interface IConfigurator<T,R> {
	
	R configure(T t);

}
