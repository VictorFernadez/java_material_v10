package com.basicsstrong.functional.section8;

public class CorkFlooring implements Flooring {

	@Override
	public void installation() {
		System.out.println("The Cork flooring is installed! ");
	}

}
