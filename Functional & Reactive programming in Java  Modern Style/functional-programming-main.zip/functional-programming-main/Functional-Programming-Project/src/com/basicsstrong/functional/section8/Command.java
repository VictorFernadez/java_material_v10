package com.basicsstrong.functional.section8;

public interface Command {
	
	public void execute();
	
}