package com.basicsstrong.functional.section8;

public class WoodenFlooring implements Flooring {
	
	@Override
	public void installation() {
		System.out.println("The Wooden flooring is installed! ");
	}

}
