package com.basicsstrong.functional.section6;

public class PureFunction {

	public int sum(int a, int b) {
		return a + b;
	}

}
