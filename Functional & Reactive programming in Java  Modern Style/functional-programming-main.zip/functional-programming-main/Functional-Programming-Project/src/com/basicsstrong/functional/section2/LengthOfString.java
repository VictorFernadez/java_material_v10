package com.basicsstrong.functional.section2;

public interface LengthOfString {
	
	public int length(String s);

}
