package com.basicsstrong.functional.section3;


@FunctionalInterface
public interface MyFunInterface {
	
	public void myMethod();
	
}
