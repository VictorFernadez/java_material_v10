package com.basicsstrong.functional.section5;

import java.util.Optional;

public class Soundcard {
	  private Optional<USB> usb;
	 
	  public Optional<USB> getUSB() {
		  return this.usb;
	  }

	}
