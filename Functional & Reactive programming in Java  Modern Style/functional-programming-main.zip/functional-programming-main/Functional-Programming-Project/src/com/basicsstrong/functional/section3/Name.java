package com.basicsstrong.functional.section3;

@FunctionalInterface
interface Name{
    
    public void myName();
}
