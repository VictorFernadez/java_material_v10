package com.basicsstrong.functional.section6;

public interface IProducer<T> {
	
	T produce();

}
