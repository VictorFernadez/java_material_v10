package com.basicsstrong.functional.section5;

import java.util.Optional;

public class Computer {
	
	 private Optional<Soundcard> soundcard;  
	 
	  public Optional<Soundcard> getSoundcard() { 
		  return this.soundcard;
}
	

}
