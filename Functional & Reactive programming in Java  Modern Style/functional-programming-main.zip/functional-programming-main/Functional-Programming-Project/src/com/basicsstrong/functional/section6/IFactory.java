package com.basicsstrong.functional.section6;

public interface IFactory<T> {
	
	T create();

}
