package com.basicsstrong.functional.section8;

public class AC {

	public void turnOn() {
		System.out.println("turning on AC");
	}

	public void turnOff() {
		System.out.println("turning off AC");
	}

	public void incTemp() {
		System.out.println("Increasing temperature");
	}

	public void decTemp() {
		System.out.println("Decreasing temperature");
	}
}
