package com.basicsstrong.functional.section5;

public class USB{
	
	private String version = "UNKNOWN";
	  
	public String getVersion(){ 
		return this.version;
	}
	
}
