package com.basicsstrong.functional.section6;


@FunctionalInterface
public interface Task {
	
	void doTask();

}
