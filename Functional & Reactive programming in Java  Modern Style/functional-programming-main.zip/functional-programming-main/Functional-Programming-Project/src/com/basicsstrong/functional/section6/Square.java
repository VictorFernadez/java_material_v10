package com.basicsstrong.functional.section6;

public class Square {
	
	private int area;

	public int getArea() {
		return area;
	}

	public void setArea(int area) {
		this.area = area;
	}

}
