module academy.learnprogramming.db {
    requires java.sql;
    requires sqlite.jdbc;
    requires academy.learnprogramming.common;
}