package dev.lpa.sealed;

public non-sealed interface BetterInterface extends SealedInterface {
}
