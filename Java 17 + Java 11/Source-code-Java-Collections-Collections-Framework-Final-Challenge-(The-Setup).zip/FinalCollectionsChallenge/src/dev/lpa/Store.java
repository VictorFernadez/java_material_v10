package dev.lpa;

public class Store {

    public static void main(String[] args) {

    }
}
