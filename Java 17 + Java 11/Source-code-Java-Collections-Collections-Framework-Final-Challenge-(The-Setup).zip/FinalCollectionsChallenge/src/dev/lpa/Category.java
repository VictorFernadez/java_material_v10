package dev.lpa;

public enum Category {PRODUCE, DAIRY, CEREAL, MEAT, BEVERAGE}
