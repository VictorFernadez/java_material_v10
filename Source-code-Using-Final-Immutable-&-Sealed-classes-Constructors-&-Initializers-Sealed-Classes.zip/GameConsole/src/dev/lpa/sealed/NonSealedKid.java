package dev.lpa.sealed;

public non-sealed class NonSealedKid extends SpecialAbstractClass {
}
