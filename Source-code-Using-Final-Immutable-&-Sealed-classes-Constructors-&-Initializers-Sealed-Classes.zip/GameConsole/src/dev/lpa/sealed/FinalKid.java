package dev.lpa.sealed;

public final class FinalKid extends SpecialAbstractClass {
}
